<?php

class AboutController
{
    public function index() {
        require __DIR__ . '/../views/about.php';
    }
}
